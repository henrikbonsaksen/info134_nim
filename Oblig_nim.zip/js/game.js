// Denne filen skal bruke Nim objektet for å
// lage nye instanser av konstruktøren something.

// Lager et nytt Nim objekt.
// var n = new Nim("Geir", "Svein", victory, 14, 2);

var name_p1 = prompt("Navn spiller 1:");
var name_p2 = prompt("Navn spiller 2:");
var total1 = prompt("Hvor mange kuler vil du leke med?");
var max = 3;
